import os
import subprocess

def run_1axis_simulation(gpu, step=2000000, output_dir='./'):
    """
    运行 1axis.py 模拟
    """
    command = f"python 1axis.py --gpu {gpu}"
    print(f"正在GPU {gpu}上运行1轴拉伸模拟，步数为 {step}...")
    
    # 执行模拟
    subprocess.run(command, shell=True)
    
    # 假设输出文件名为 'output_1axis.txt'
    output_file = os.path.join(output_dir, 'output_1axis.txt')
    return output_file

def run_3axis_simulation(gpu, step=2000000, output_dir='./'):
    """
    运行 3axis.py 模拟
    """
    command = f"python 3axis.py --gpu {gpu}"
    print(f"正在GPU {gpu}上运行3轴拉伸模拟，步数为 {step}...")
    
    # 执行模拟
    subprocess.run(command, shell=True)
    
    # 假设输出文件名为 'output_3axis.txt'
    output_file = os.path.join(output_dir, 'output_3axis.txt')
    return output_file

def process_stress_strain_data(input_file_path, output_file_path='stress-strain.txt'):
    """
    使用tensile.py处理模拟输出，计算应力应变曲线
    """
    print(f"正在处理数据文件 {input_file_path}，生成应力应变曲线...")
    
    # 调用 tensile.py 处理输出
    command = f"python tensile.py {input_file_path}"
    subprocess.run(command, shell=True)

    # 如果需要，重命名输出文件
    os.rename('stress-strain.txt', output_file_path)
    print(f"应力应变数据已保存到 {output_file_path}")

def main():
    # 设置GPU设备，假设使用GPU 0
    gpu = 0
    output_dir = './simulation_output'

    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 运行 1轴拉伸模拟
    output_file_1axis = run_1axis_simulation(gpu, output_dir=output_dir)
    # 处理输出文件，计算应力应变曲线
    process_stress_strain_data(output_file_1axis)

    # 运行 3轴拉伸模拟
    output_file_3axis = run_3axis_simulation(gpu, output_dir=output_dir)
    # 处理输出文件，计算应力应变曲线
    process_stress_strain_data(output_file_3axis)

if __name__ == "__main__":
    main()


