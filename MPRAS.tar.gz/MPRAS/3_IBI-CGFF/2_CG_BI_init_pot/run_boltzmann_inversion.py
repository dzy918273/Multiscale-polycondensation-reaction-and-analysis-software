import subprocess
import os

def run_boltzmann_inversion():
    # 输入数据文件路径（假设数据文件已在 1_AA_ref_conf 中生成）
    input_folder = "1_AA_ref_conf"  # 生成数据文件的目录
    output_folder = "2_CG_BI_init_pot"  # 用于存储反演结果的目录

    data_files = {
        'angle': os.path.join(input_folder, 'angle_data.txt'),
        'bond': os.path.join(input_folder, 'bond_data.txt'),
        'dihedral': os.path.join(input_folder, 'dihedral_data.txt'),
        'nonbond': os.path.join(input_folder, 'nonbond_data.txt')
    }

    output_files = {
        'angle': os.path.join(output_folder, 'angle_output.csv'),
        'bond': os.path.join(output_folder, 'bond_output.csv'),
        'dihedral': os.path.join(output_folder, 'dihedral_output.csv'),
        'nonbond': os.path.join(output_folder, 'nonbond_output.csv')
    }

    # 对每个数据文件调用相应的Boltzmann反演脚本
    for key, input_file in data_files.items():
        output_file = output_files[key]
        script_name = f'boltzmann_inverse_{key}.py'

        # 调用外部脚本执行反演
        print(f"Processing {key} data...")
        subprocess.run(['python', script_name, input_file, output_file])
        print(f"Finished processing {key}. Results saved in {output_file}")

if __name__ == "__main__":
    run_boltzmann_inversion()

