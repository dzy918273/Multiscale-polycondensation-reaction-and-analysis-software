import numpy as np
import time
import datetime
from io import StringIO
from xml.etree import cElementTree
import pandas as pd
from pandas import read_csv
import sys
from itertools import chain

# 防止创建 .pyc 文件
sys.dont_write_bytecode = True

class HOOMDXMLParser:
    """
    解析 HOOMD XML 文件并提取所需属性的类。

    属性：
        filename (str): 要解析的 XML 文件名。
        needed (list): 要提取的属性列表。
        box (np.array): 模拟盒的尺寸。
        nodes (dict): 存储提取数据的字典。
    """

    @staticmethod
    def _get_attrib(dd):
        """
        将属性字典转换为结构化的 numpy 数组。

        参数：
            dd (dict): 属性字典。

        返回：
            np.array: 结构化的 numpy 数组。
        """
        dt = eval('[' + ','.join(["('%s', int)" % key for key in dd.keys()]) + ']')
        values = [tuple(dd.values())]
        return np.array(values, dtype=dt)

    def __init__(self, filename, needed=[]):
        """
        使用文件名和所需属性初始化解析器。

        参数：
            filename (str): 要解析的 XML 文件。
            needed (list): 要提取的属性列表。
        """
        self.filename = filename
        self.needed = needed
        self.nodes = {}
        self.box = None
        self._parse_xml()

    def _parse_xml(self):
        """解析 XML 文件并提取必要数据。"""
        try:
            tree = cElementTree.ElementTree(file=self.filename)
            root = tree.getroot()
            configuration = root[0]
            self.configure = self._get_attrib(configuration.attrib)
            for element in configuration:
                if element.tag == 'box':
                    self.box = np.array([float(element.attrib['lx']),
                                         float(element.attrib['ly']),
                                         float(element.attrib['lz'])])
                    continue
                if (len(self.needed) != 0) and (element.tag not in self.needed):
                    continue
                self.nodes[element.tag] = read_csv(StringIO(element.text), delim_whitespace=True, squeeze=1, header=None).values
        except Exception as e:
            print(f"解析 XML 文件 '{self.filename}' 时出错: {e}", file=sys.stderr)

def calculate_distance(point1, point2):
    """计算两个点之间的欧几里得距离。"""
    return np.linalg.norm(point2 - point1)

def calculate_bond_distances(xml_name, bond_infos):
    """
    从提供的 XML 文件中计算键合距离。

    参数：
        xml_name (str): XML 文件名。
        bond_infos (list): 计算键合所需的信息。

    返回：
        tuple: 三个距离列表 (AB, BB, SS)。
    """
    AB, BB, SS = [], [], []
    xml_parser = HOOMDXMLParser(xml_name, ["position", "bond"])
    position = xml_parser.nodes['position']
    for bond_info in bond_infos:
        bond_name = bond_info[0]
        i, j = bond_info[1], bond_info[2]
        distance = calculate_distance(position[i], position[j])
        if bond_name in ['A-B', 'A-C']:
            AB.append(distance)
        elif bond_name == 'B-C':
            BB.append(distance)
        else:
            SS.append(distance)
    return AB, BB, SS

def round_to_nearest(value, step=0.001):
    """将值四舍五入到最接近的指定步长。"""
    return round(value / step) * step

def create_distribution_dataframe(distances):
    """
    从距离创建频率分布 DataFrame。

    参数：
        distances (list): 距离列表。

    返回：
        pd.DataFrame: 包含频率分布的 DataFrame。
    """
    rounded_distances = [round_to_nearest(d) for d in distances]
    data_string = '\n'.join(f'{d:.3f}' for d in rounded_distances)
    data = pd.read_csv(StringIO(data_string), header=None, float_precision='round_trip')
    data = data[data[0] < 1]  # 过滤出小于 1 的距离
    denominator = len(data[0])
    frequency = data[0].value_counts().sort_index()
    distribution_df = frequency.reset_index()
    distribution_df[0] /= denominator  # 归一化频率
    distribution_df.columns = ['Distance', 'Frequency']
    return distribution_df

def main():
    """主函数，用于执行键合距离计算。"""
    bond_infos = sys.argv[2:]  # 从命令行参数获取键合信息
    AB, BB, SS = [], [], []
    start_time = time.time()

    for xml_file in sys.argv[1:]:
        ab, bb, ss = calculate_bond_distances(xml_file, bond_infos)
        AB.append(ab)
        BB.append(bb)
        SS.append(ss)
        elapsed_time = time.time() - start_time
        print(f"处理 '{xml_file}'：耗时 = {datetime.timedelta(seconds=elapsed_time)}", flush=True)

    # 为每种类型的键合距离创建 DataFrame
    AB_df = create_distribution_dataframe(list(chain.from_iterable(AB)))
    BB_df = create_distribution_dataframe(list(chain.from_iterable(BB)))
    SS_df = create_distribution_dataframe(list(chain.from_iterable(SS)))

    # 将结果保存到文件
    AB_df.to_csv('CG_AB.dat', index=False, header=None, sep=' ')
    BB_df.to_csv('CG_BB.dat', index=False, header=None, sep=' ')
    SS_df.to_csv('CG_SS.dat', index=False, header=None, sep=' ')

if __name__ == '__main__':
    main()


