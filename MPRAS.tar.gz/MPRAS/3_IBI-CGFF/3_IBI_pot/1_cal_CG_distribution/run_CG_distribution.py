import subprocess
import os

def run_cg_distribution(xml_files):
    """
    处理粗粒化分布的计算（角度、键长、二面角、径向分布）。
    """
    # 文件路径
    cg_distribution_folder = "3_IBI-CGFF/3_IBI_pot/1_cal_CG_distribution"
    
    # 角度数据提取
    print("开始计算角度分布...")
    subprocess.run(['python', os.path.join(cg_distribution_folder, 'dfget_CGangle.py')] + xml_files)

    # 键长数据提取
    print("开始计算键长分布...")
    subprocess.run(['python', os.path.join(cg_distribution_folder, 'dfget_CGbond.py')] + xml_files)

    # 二面角数据提取
    print("开始计算二面角分布...")
    subprocess.run(['python', os.path.join(cg_distribution_folder, 'dfget_CGdihedral.py')] + xml_files)

    # 径向分布数据提取
    print("开始计算径向分布...")
    subprocess.run(['python', os.path.join(cg_distribution_folder, 'dfget_CGrdf.py')] + xml_files)

    print("所有计算完成。")

if __name__ == "__main__":
    # 输入XML文件路径
    xml_files = ["particle000.xml", "particle001.xml"]  # 示例文件

    # 执行分布计算
    run_cg_distribution(xml_files)


