import numpy as np
import time
import datetime
from io import StringIO
from xml.etree import cElementTree
import pandas as pd
import sys
from itertools import chain

sys.dont_write_bytecode = True

class HoomdXMLParser:
    """
    解析HOOMD XML文件以提取粒子位置信息和二面角数据。

    用法：
        xml_parser = HoomdXMLParser("particle000.xml", ["position", "dihedral"])
        box_dimensions = xml_parser.box
    """

    @staticmethod
    def _get_attrib(attributes):
        """
        从给定的字典中提取属性并返回NumPy数组。

        :param attributes: 字典，包含XML元素的属性
        :return: NumPy数组，包含元素的属性值
        """
        dtype = eval('[' + ','.join(["('%s', int)" % key for key in attributes.keys()]) + ']')
        values = [tuple(attributes.values())]
        return np.array(values, dtype=dtype)

    def __init__(self, filename, required_tags=[]):
        """
        初始化HoomdXMLParser类并解析XML文件。

        :param filename: XML文件名
        :param required_tags: 需要提取的标签列表
        """
        tree = cElementTree.ElementTree(file=filename)
        root = tree.getroot()
        configuration = root[0]
        self.configure = self._get_attrib(configuration.attrib)
        self.nodes = {}
        for element in configuration:
            if element.tag == 'box':
                self.box = np.array([float(element.attrib['lx']),
                                     float(element.attrib['ly']),
                                     float(element.attrib['lz'])])
                continue
            if required_tags and (element.tag not in required_tags):
                continue
            self.nodes[element.tag] = pd.read_csv(StringIO(element.text), delim_whitespace=True, squeeze=1, header=None).values

def calculate_dihedral(p1, p2, p3, p4):
    """
    计算四个粒子位置形成的二面角。

    :param p1: 第一个粒子的位置
    :param p2: 第二个粒子的位置
    :param p3: 第三个粒子的位置
    :param p4: 第四个粒子的位置
    :return: 二面角（度数）
    """
    points = np.array([p1, p2, p3, p4])
    vectors = points[:-1] - points[1:]
    vectors[0] *= -1  # 翻转第一个向量
    # 投影到平面
    projected_vectors = np.array([
        vec - (vec.dot(vectors[1]) / np.linalg.norm(vectors[1])**2) * vectors[1]
        for vec in [vectors[0], vectors[2]]
    ])
    projected_vectors /= np.linalg.norm(projected_vectors, axis=1)[:, np.newaxis]

    b1 = vectors[1] / np.linalg.norm(vectors[1])
    x = np.dot(projected_vectors[0], projected_vectors[1])
    m = np.cross(projected_vectors[0], b1)
    y = np.dot(m, projected_vectors[1])

    return np.degrees(np.arctan2(y, x))

def calculate_dihedrals_from_xml(xml_filename, dihedral_info):
    """
    从XML文件中计算给定的二面角信息。

    :param xml_filename: XML文件名
    :param dihedral_info: 二面角信息的列表
    :return: 二面角数据
    """
    ABBA_angles = []
    BBAB_angles = []
    xml_parser = HoomdXMLParser(xml_filename, ["position", "image"])
    positions = xml_parser.nodes['position'] + xml_parser.nodes['image'] * xml_parser.box

    for info in dihedral_info:
        dihedral_name, i, j, k, l = info
        p1, p2, p3, p4 = positions[i], positions[j], positions[k], positions[l]
        dihedral_angle = calculate_dihedral(p1, p2, p3, p4)

        if dihedral_name == 'A-C-B-A':
            ABBA_angles.append(dihedral_angle)
        else:
            BBAB_angles.append(dihedral_angle)

    return ABBA_angles, BBAB_angles

def round_to_nearest(x, base=1):
    """
    将数值四舍五入到最接近的基数。

    :param x: 输入值
    :param base: 基数（默认为1）
    :return: 四舍五入后的值
    """
    return round(x / base) * base

def create_distribution_dataframe(dihedral_angles):
    """
    根据二面角列表创建频率分布数据框。

    :param dihedral_angles: 二面角列表
    :return: 包含二面角频率的Pandas数据框
    """
    angle_counts = pd.Series(dihedral_angles).value_counts().sort_index()
    distribution = angle_counts / len(dihedral_angles)  # 归一化
    return distribution.reset_index().rename(columns={'index': 'Dihedral', 0: 'Frequency'})

# 主程序入口
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python dfget_CGdihedral.py <xml_file1> <xml_file2> ...")
        sys.exit(1)

    dihedral_info_list = []  # 这里应该根据实际情况填充二面角信息
    ABBA_angles_list = []
    BBAB_angles_list = []

    start_time = time.time()
    for xml_file in sys.argv[1:]:
        ABBA_angles, BBAB_angles = calculate_dihedrals_from_xml(xml_file, dihedral_info_list)
        ABBA_angles_list.append(ABBA_angles)
        BBAB_angles_list.append(BBAB_angles)

        elapsed_time = time.time() - start_time
        print(f"处理文件 {xml_file} 完成，耗时 {str(datetime.timedelta(seconds=elapsed_time))}")

    # 汇总所有二面角数据
    ABBA_combined = create_distribution_dataframe(list(chain.from_iterable(ABBA_angles_list)))
    BBAB_combined = create_distribution_dataframe(list(chain.from_iterable(BBAB_angles_list)))

    # 输出结果
    ABBA_combined.to_csv('CG_ABBA.dat', index=False, header=None, sep=' ')
    BBAB_combined.to_csv('CG_BBAB.dat', index=False, header=None, sep=' ')

    print("所有计算完成，结果已保存。")


