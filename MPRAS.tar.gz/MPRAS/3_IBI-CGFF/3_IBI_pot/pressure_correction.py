import numpy as np
import matplotlib.pyplot as plt
from sys import argv

def linear_correction(x, A):
    """对 y 值应用基于参数 A 的线性修正。"""
    return A * (1 - x / 2.5)

def load_and_correct_data(filename, correction_param):
    """从文件中加载数据，应用修正，并保存修正后的数据。"""
    # 从指定文件加载数据
    x, y = np.loadtxt(filename, unpack=True)
    
    # 对 y 值应用线性修正
    corrected_y = y + linear_correction(x, correction_param)
    
    # 保存修正后的数据到新文件
    new_filename = filename.replace(".dat", "-corrected.dat")
    np.savetxt(new_filename, np.c_[x, corrected_y], fmt='%.6f')
    
    return x, corrected_y

def plot_data(ax, x, y, corrected_y, label_init='init', label_correct='correct'):
    """在提供的坐标轴上绘制初始和修正后的数据。"""
    ax.set_xlim(0, 1.4)
    ax.set_ylim(-2, 2)
    ax.plot(x, y, color='red', label=label_init)
    ax.plot(x, corrected_y, color='blue', label=label_correct)
    ax.legend()

def main():
    # 不同数据集的修正参数
    correction_params = {
        "nb-AA-3f.dat": -0.06,
        "nb-AB-3f.dat": -0.10,
        "nb-AC.dat": -0.15,
        "nb-SA-3f.dat": -0.147,
        "nb-SB-3f.dat": -0.18,
        "nb-SC.dat": -0.18
    }
    
    # 准备绘图的图形
    fig, axs = plt.subplots(2, 3, figsize=(15, 10))
    axs = axs.flatten()  # 将坐标轴数组展平，便于迭代

    # 加载、修正并绘制每个数据集
    for i, (filename, correction_param) in enumerate(correction_params.items()):
        x, corrected_y = load_and_correct_data(filename, correction_param)
        plot_data(axs[i], x, np.loadtxt(filename, unpack=True)[1], corrected_y)

    # 调整布局并显示图形
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()


