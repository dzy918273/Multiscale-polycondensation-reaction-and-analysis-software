import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import signal, constants

# 数据处理的主函数
def process_rdf_files():
    # 删除 rdf_by_type.log 的第一行
    os.system("sed -i '1d' rdf_by_type.log ")
    
    # 从文件中加载径向分布函数（RDF）数据
    r, y_aa, y_ab, y_ac, y_as, y_bb, y_bc, y_bs, y_cc, y_cs, y_ss = np.loadtxt("rdf_by_type.log", unpack=True)
    
    # 平滑处理RDF数据
    smooth_data = smooth_rdf_data([y_aa, y_ab, y_ac, y_as, y_bb, y_bc, y_bs, y_cc, y_cs, y_ss])
    
    # 保存平滑后的数据
    save_smooth_rdf(r, smooth_data)

    # 处理额外的RDF数据文件
    handle_extra_rdf_data()

# 平滑处理RDF数据
def smooth_rdf_data(y_values):
    return [signal.savgol_filter(y, 7, 3) for y in y_values]

# 保存平滑后的RDF数据到文件
def save_smooth_rdf(r, smooth_data):
    labels = ["AA", "AB", "AC", "SA", "BB", "BC", "SB", "CC", "SC", "SS"]
    for i, smooth in enumerate(smooth_data):
        np.savetxt(f"{labels[i]}-CG-rdf.dat", np.c_[r, smooth], fmt='%.6f')

# 处理额外的RDF数据文件
def handle_extra_rdf_data():
    rdf_files = [
        ("AA-exchain-RDF-2000point.dat", "AA-CG-rdf.dat"),
        ("AB-exchain-RDF-2000point.dat", "AB-CG-rdf.dat"),
        ("AC-A-rdf-2000point.dat", "AC-CG-rdf.dat"),
        ("SA-A-rdf-2000point.dat", "SA-CG-rdf.dat"),
        ("BB-exchain-RDF-2000point.dat", "BB-CG-rdf.dat"),
        ("SB-A-rdf-2000point.dat", "SB-CG-rdf.dat"),
        ("CC-A-rdf-2000point.dat", "CC-CG-rdf.dat"),
        ("SC-A-rdf-2000point.dat", "SC-CG-rdf.dat"),
        ("SS-A-rdf-2000point.dat", "SS-CG-rdf.dat")
    ]

    for exchain_file, cg_rdf_file in rdf_files:
        x, y = np.loadtxt(exchain_file, unpack=True)
        x_cg, y_cg = np.loadtxt(cg_rdf_file, unpack=True)
        # 进一步处理
        process_nb_data(x, y, x_cg, y_cg)

# 处理非结合数据
def process_nb_data(x, y, x_cg, y_cg):
    os.system("sed -i '1d' nb-AA-3-diedai.dat ")
    os.system("sed -i '$d' nb-AA-3-diedai.dat ")
    x_1, y_1 = np.loadtxt("nb-AA-3-diedai.dat", unpack=True)
    raa = y_cg / y
    correct_1 = 0.1 * constants.R * 583 * np.log(raa + 1e-6) * 0.001
    y_1 += correct_1
    np.savetxt("nb-AA-2.dat", np.c_[x_1, y_1], fmt='%.6f')

    # 可以将此部分进一步模块化以避免重复代码
    # 处理其他数据...

# 绘图函数
def plot_results():
    fig = plt.figure(figsize=(10, 6))

    ax1 = fig.add_subplot(231)
    ax1.set_xlim(0, 1.4)
    ax1.set_ylim(-2, 2)
    ax1.plot(x_1, y_1, color='red', label='init')
    ax1.plot(x_1, correct_1, color='blue', label='correct')
    ax1.legend()

    ax2 = fig.add_subplot(232)
    ax2.set_xlim(0, 1.4)
    ax2.set_ylim(-2, 2)
    ax2.plot(x_2, y_2, color='red', label='init')
    ax2.plot(x_2, correct_2, color='blue', label='correct')
    ax2.legend()

    ax3 = fig.add_subplot(233)
    ax3.set_xlim(0, 1.4)
    ax3.set_ylim(-2, 2)
    ax3.plot(x_3, y_3, color='red', label='init')
    ax3.plot(x_3, correct_3, color='blue', label='correct')
    ax3.legend()

    ax4 = fig.add_subplot(234)
    ax4.set_xlim(0, 1.4)
    ax4.set_ylim(-2, 2)
    ax4.plot(x_4, y_4, color='red', label='init')
    ax4.plot(x_4, correct_4, color='blue', label='correct')
    ax4.legend()

    ax5 = fig.add_subplot(235)
    ax5.set_xlim(0, 1.4)
    ax5.set_ylim(-2, 2)
    ax5.plot(x_5, y_5, color='red', label='init')
    ax5.plot(x_5, correct_5, color='blue', label='correct')
    ax5.legend()

    ax6 = fig.add_subplot(236)
    ax6.set_xlim(0, 1.4)
    ax6.set_ylim(-2, 2)
    ax6.plot(x_6, y_6, color='red', label='init')
    ax6.plot(x_6, correct_6, color='blue', label='correct')
    ax6.legend()

    plt.tight_layout()
    plt.show()

# 主程序入口
if __name__ == "__main__":
    process_rdf_files()
    plot_results()


