import os
import subprocess

# 定义路径
BASE_DIR = "/path/to/your/project"  # 请替换为你的实际项目路径
IBI_CGFF_DIR = os.path.join(BASE_DIR, "3_IBI-CGFF")
AA_REF_CONF_DIR = os.path.join(IBI_CGFF_DIR, "1_AA_ref_conf")
CG_BI_INIT_POT_DIR = os.path.join(IBI_CGFF_DIR, "2_CG_BI_init_pot")
IBI_POT_DIR = os.path.join(IBI_CGFF_DIR, "3_IBI_pot")
CAL_CG_DISTRIBUTION_DIR = os.path.join(IBI_POT_DIR, "1_cal_CG_distribution")

# 文件路径
AA_BOND_TARGET_FILE = os.path.join(AA_REF_CONF_DIR, "AA_bond_target.dat")
CG_BOND_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_bond.dat")
CG_BOND_UPDATED_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_bond_updated.dat")
AA_ANGLE_TARGET_FILE = os.path.join(AA_REF_CONF_DIR, "AA_angle_target.dat")
CG_ANGLE_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_angle.dat")
CG_ANGLE_UPDATED_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_angle_updated.dat")
AA_DIHEDRAL_TARGET_FILE = os.path.join(AA_REF_CONF_DIR, "AA_dihedral_target.dat")
CG_DIHEDRAL_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_dihedral.dat")
CG_DIHEDRAL_UPDATED_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_dihedral_updated.dat")
AA_RDF_TARGET_FILE = os.path.join(AA_REF_CONF_DIR, "AA_rdf_target.dat")
CG_RDF_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_rdf.dat")
CG_RDF_UPDATED_FILE = os.path.join(CAL_CG_DISTRIBUTION_DIR, "CG_rdf_updated.dat")

# 修正因子
BOND_CORRECTION_FACTOR = 0.1
ANGLE_CORRECTION_FACTOR = 0.1
DIHEDRAL_CORRECTION_FACTOR = 0.1
RDF_CORRECTION_FACTOR = 0.1

def run_command(command):
    """
    执行命令行命令
    """
    print(f"Running command: {command}")
    subprocess.run(command, shell=True, check=True)

def run_ibi_bond():
    """
    执行 IBI_bond.py 脚本
    """
    print("Running IBI_bond.py...")
    command = f"python {IBI_POT_DIR}/IBI_bond.py {CG_BOND_FILE} {AA_BOND_TARGET_FILE} {CG_BOND_UPDATED_FILE} {BOND_CORRECTION_FACTOR}"
    run_command(command)

def run_ibi_angle():
    """
    执行 IBI_angle.py 脚本
    """
    print("Running IBI_angle.py...")
    command = f"python {IBI_POT_DIR}/IBI_angle.py {CG_ANGLE_FILE} {AA_ANGLE_TARGET_FILE} {CG_ANGLE_UPDATED_FILE} {ANGLE_CORRECTION_FACTOR}"
    run_command(command)

def run_ibi_dihedral():
    """
    执行 IBI_dihedral.py 脚本
    """
    print("Running IBI_dihedral.py...")
    command = f"python {IBI_POT_DIR}/IBI_dihedral.py {CG_DIHEDRAL_FILE} {AA_DIHEDRAL_TARGET_FILE} {CG_DIHEDRAL_UPDATED_FILE} {DIHEDRAL_CORRECTION_FACTOR}"
    run_command(command)

def run_ibi_rdf():
    """
    执行 IBI_rdf.py 脚本
    """
    print("Running IBI_rdf.py...")
    command = f"python {IBI_POT_DIR}/IBI_rdf.py {CG_RDF_FILE} {AA_RDF_TARGET_FILE} {CG_RDF_UPDATED_FILE} {RDF_CORRECTION_FACTOR}"
    run_command(command)

def run_pressure_correction():
    """
    执行 pressure_correction.py 脚本
    """
    print("Running pressure_correction.py...")
    command = f"python {IBI_POT_DIR}/pressure_correction.py {CG_RDF_UPDATED_FILE} {CG_BOND_UPDATED_FILE} {CG_ANGLE_UPDATED_FILE} {CG_DIHEDRAL_UPDATED_FILE}"
    run_command(command)

def main():
    """
    主调度函数
    """
    # 按顺序运行IBI过程
    print("Starting IBI process...")

    run_ibi_bond()  # 迭代bond部分
    run_ibi_angle()  # 迭代angle部分
    run_ibi_dihedral()  # 迭代dihedral部分
    run_ibi_rdf()  # 迭代rdf部分
    run_pressure_correction()  # 进行pressure correction

    print("IBI process completed successfully!")

if __name__ == "__main__":
    main()


