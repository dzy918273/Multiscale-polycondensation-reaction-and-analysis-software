import os
import numpy as np
from scipy import signal
from scipy import constants

# 常量定义
TEMPERATURE = 463  # 温度 (K)
VOLUME_CONVERSION = 0.001  # 体积单位转换 (mL to L)

def load_data(file_name):
    """
    从文件中加载数据。
    
    参数：
    file_name: 需要加载的数据文件名。
    
    返回：
    r: 第一列数据
    y: 第二列数据
    """
    r, y = np.loadtxt(file_name, unpack=True)
    return r, y

def smooth_data(y, window_length=7, polyorder=3):
    """
    对数据进行平滑处理。
    
    参数：
    y: 需要平滑的数据
    window_length: 窗口长度，必须是奇数
    polyorder: 多项式的阶数
    
    返回：
    smooth_y: 平滑后的数据
    """
    smooth_y = signal.savgol_filter(y, window_length, polyorder)
    return smooth_y

def save_data(filename, data):
    """
    保存数据到文件。
    
    参数：
    filename: 输出文件名
    data: 要保存的数据，通常为二位数组
    """
    np.savetxt(filename, data, fmt='%.6f')

def calculate_correction(y_cg, y_atom, correction_factor):
    """
    计算修正值。
    
    参数：
    y_cg: CG数据
    y_atom: 原始原子数据
    correction_factor: 修正因子
    
    返回：
    修正后的数据
    """
    ratio = y_cg / y_atom  # 计算比率
    correction = correction_factor * constants.R * TEMPERATURE * np.log(ratio + 1e-6) * VOLUME_CONVERSION
    return correction

def process_dihedral_distribution():
    """
    处理二面角分布数据并应用修正。
    """
    # 读取 CG 分布数据并进行平滑处理
    r_cg, y_cg = load_data("cg-dh-2.dat.0")  # CG 分布
    smooth_cg = smooth_data(y_cg)
    save_data("AA-CG-dh.dat", np.c_[r_cg, smooth_cg])

    # 读取原子分布数据
    x_atom, y_atom = load_data("all-dh.dat.0")  # 原子分布

    # 读取 CG-1 势能数据
    x_pot, y_pot = load_data("cg-dh-pot-2.dat")  # CG-1 势能
    x_cg, y_cg_smooth = load_data("AA-CG-dh.dat")  # 已平滑的 CG 数据

    # 计算修正
    correction = calculate_correction(y_cg_smooth, y_atom, correction_factor=0.5)
    y_pot_corrected = y_pot + correction  # 应用修正

    # 保存修正后的势能数据
    save_data("cg-dh-pot-3.dat", np.c_[x_pot, y_pot_corrected])

def main():
    """
    主函数，启动处理流程。
    """
    print("开始处理二面角分布数据...")
    process_dihedral_distribution()
    print("处理完成，结果已保存。")

if __name__ == "__main__":
    main()


