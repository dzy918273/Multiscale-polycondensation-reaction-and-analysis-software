import os
import numpy as np
import pandas as pd
from scipy import constants

# 常量定义
TEMPERATURE = 493  # 温度 (K)
VOLUME_CONVERSION = 0.001  # 体积单位转换 (mL to L)

def remove_first_and_last_line(filename):
    """
    去除指定文件的首尾行以清理数据。
    
    参数：
    filename: 需要处理的文件名。
    """
    os.system(f"sed -i '1d' {filename}")  # 删除第一行
    os.system(f"sed -i '$d' {filename}")  # 删除最后一行

def read_data(file_name):
    """
    从给定的文件中读取数据。
    
    参数：
    file_name: 需要读取的数据文件名。
    
    返回：
    x: 第一列数据
    y: 第二列数据
    """
    x, y = np.loadtxt(file_name, unpack=True)
    return x, y

def calculate_correction(y_cg, y, correction_factor):
    """
    计算修正值。
    
    参数：
    y_cg: CG数据
    y: 原始数据
    correction_factor: 修正因子
    
    返回：
    修正后的数据
    """
    r = y_cg / y  # 计算比率
    correction = correction_factor * constants.R * TEMPERATURE * np.log(r + 1e-6) * VOLUME_CONVERSION
    return correction

def save_corrected_data(x, y_corrected, output_filename):
    """
    将修正后的数据保存到输出文件。
    
    参数：
    x: 自变量数据
    y_corrected: 修正后的因变量数据
    output_filename: 输出文件名
    """
    np.savetxt(output_filename, np.c_[x, y_corrected], fmt='%.6f')

def process_data(log_filename, data_filename, output_filename, correction_factor):
    """
    处理指定的日志文件和数据文件，应用修正并保存结果。
    
    参数：
    log_filename: 日志文件名
    data_filename: 数据文件名
    output_filename: 输出文件名
    correction_factor: 修正因子
    """
    # 清理日志文件
    remove_first_and_last_line(log_filename)

    # 读取数据
    x_log, y_log = read_data(log_filename)
    x_data, y_data = read_data(data_filename)

    # 计算修正值并应用
    correction = calculate_correction(y_data, y_log, correction_factor)
    y_corrected = y_log + correction

    # 保存修正后的数据
    save_corrected_data(x_log, y_corrected, output_filename)

def main():
    """
    主函数，处理多个文件并保存修正后的数据。
    """
    # 定义需要处理的文件及其修正因子
    files_to_process = [
        ("b-BZ-CG-1.log", "b-BZ-CG-fenbu-s-3000.dat", "b-BZ-CG-22.log", 0.1),
        ("b-XY-CG-1.log", "b-XY-CG-fenbu-s-3000.dat", "b-XY-CG-22.log", 0.12),
        ("b-ZZ-CG-1.log", "b-ZZ-CG-fenbu-s-3000.dat", "b-ZZ-CG-22.log", 0.12),
    ]

    # 逐个处理文件
    for log_file, data_file, output_file, correction in files_to_process:
        print(f"Processing {log_file} with correction factor {correction}...")
        process_data(log_file, data_file, output_file, correction)
        print(f"Saved corrected data to {output_file}")

if __name__ == "__main__":
    main()


