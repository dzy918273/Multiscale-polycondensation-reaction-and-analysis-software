import MDAnalysis as mda
from MDAnalysis import transformations
import numpy as np
import pandas as pd
from io import StringIO
import matplotlib.pyplot as plt
from collections import deque
import math
from itertools import chain
import os
import time
import datetime

# 计算两个向量之间的角度
def cal_angle(p1, p2, p3):
    """计算由三个点定义的角度"""
    v1 = p2 - p1
    v2 = p3 - p2
    cosine_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
    angle = np.arccos(np.clip(cosine_angle, -1.0, 1.0)) * (180.0 / np.pi)  # 转换为度数
    return angle

# 获取CG bead的角度
def get_CG_bead_angle(Universe, frame, N, resgroup, resname):
    """计算特定帧中CG bead之间的角度"""
    u = Universe
    u.trajectory[frame]
    rescm = [res.center_of_mass(compound='group') for res in resgroup]
    
    ABB = deque([])  # 存储A-B-B角度
    BAB = deque([])  # 存储B-A-B角度
    
    for i in range(len(resgroup) - 2):
        p1, p2, p3 = rescm[i], rescm[i + 1], rescm[i + 2]
        n1, n2, n3 = resname[i], resname[i + 1], resname[i + 2]
        
        angle_name = f"{n1}-{n2}-{n3}"
        angle = cal_angle(p1, p2, p3)

        if (i // N) == ((i + 1) // N) == ((i + 2) // N):
            if angle_name in ['A-B-B', 'B-B-A']:
                ABB.append(angle)
            else:
                BAB.append(angle)

    return ABB, BAB

# 读取并初始化MDAnalysis Universe
def initialize_universe():
    """初始化MDAnalysis Universe"""
    u = mda.Universe('zzzz-tuihuo-final-eq.tpr', 'zzzz-tuihuo-final-eq.xtc')
    ag = u.atoms
    transform = mda.transformations.unwrap(ag)
    u.trajectory.add_transformations(transform)
    return u

# 分割bead组并准备数据
def prepare_bead_groups():
    """准备bead组"""
    BEAD_A = BEAD_A.split('residue')
    BEAD_B1 = BEAD_B1.split('residue')
    BEAD_B2 = BEAD_B2.split('residue')
    BEAD_S1 = BEAD_S1.split('residue')
    BEAD_S2 = BEAD_S2.split('residue')

    BEAD_B = [bead for pair in zip(BEAD_B1, BEAD_B2) for bead in pair]
    BEAD_S = [bead for pair in zip(BEAD_S1, BEAD_S2) for bead in pair]

    BEAD_ABB = []
    ABB_resname = []
    for i in range(len(BEAD_B1)):
        BEAD_ABB.extend([BEAD_A[i], BEAD_B1[i], BEAD_B2[i]])
        ABB_resname.extend(['A', 'B', 'B'])

    return BEAD_ABB, ABB_resname

# 将角度数据写入文件
def write_angle_data(abb, bab):
    """将角度数据写入文件"""
    A_B_B = cal_angle_DF(abb)
    B_A_B = cal_angle_DF(bab)

    A_B_B.to_csv('ABB.dat', index=0, header=None, sep=' ')
    B_A_B.to_csv('BAB.dat', index=0, header=None, sep=' ')

# 主函数
def main():
    """主函数"""
    u = initialize_universe()
    BEAD_ABB, ABB_resname = prepare_bead_groups()

    abb = deque([])
    bab = deque([])
    N = 27

    time1 = time.time()
    for frame in range(1, len(u.trajectory), 1):
        ABB, BAB = get_CG_bead_angle(u, frame, N, BEAD_ABB, ABB_resname)
        abb.append(ABB)
        bab.append(BAB)

        time2 = time.time()
        spend_time = str(datetime.timedelta(seconds=time2 - time1))
        print(f"计算帧 = {frame}  花费时间 = {spend_time}", flush=True)

    abb = list(chain.from_iterable(abb))
    bab = list(chain.from_iterable(bab))

    write_angle_data(abb, bab)
    print("任务完成")

if __name__ == "__main__":
    main()


