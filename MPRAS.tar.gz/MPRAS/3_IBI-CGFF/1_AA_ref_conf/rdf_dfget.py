import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt
import numba
from numba import jit
import math
import time
import datetime

# 使用NumPy加速计算距离，排除1-3原子组分
@jit(nopython=True)
def new_cal_dis_exclude_1_3(CM1, CM2, index_g1, index_g2, box):
    len_mol = 27  # 假设每个分子包含27个原子
    max_points = 100000000
    point = np.zeros(max_points)
    counter = 0
    loop = 0
    
    # 遍历两个组分中的每个原子
    for i in range(CM1.shape[0]):
        for j in range(CM2.shape[0]):
            xi, yi, zi = CM1[i]
            xj, yj, zj = CM2[j]
            
            # 计算周期性边界条件下的距离
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            dx -= box * math.floor(dx / box + 0.5)
            dy -= box * math.floor(dy / box + 0.5)
            dz -= box * math.floor(dz / box + 0.5)
            dis = math.sqrt(dx * dx + dy * dy + dz * dz)

            # 排除1-3原子间的相互作用
            index_i = index_g1[i]
            index_j = index_g2[j]
            if (index_i // len_mol) == (index_j // len_mol) and abs(index_i - index_j) <= 25:
                dis = 0
            
            point[counter] = dis
            loop += 1
            if dis == 0:
                loop -= 1
            counter += 1

    return point, loop

# RDF类定义
class new_RDF(object):
    def __init__(self, Universe, g1, g2, index_g1, index_g2, binsize):
        self.binsize = binsize
        self.u = Universe
        self.g1 = g1
        self.g2 = g2
        self.index_g1 = index_g1
        self.index_g2 = index_g2
        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5 * self.binsize, self.origin_box / 2, self.binsize)
        self.rdf_merge = np.zeros(self.X.shape[0] - 1)
        self.N = 0  # 初始化粒子数
        
    def single_frame(self, frame):
        """计算单个帧的RDF"""
        # 计算距离并更新RDF合并
        dis, loop = new_cal_dis_exclude_1_3(self.g1.positions, self.g2.positions, self.index_g1, self.index_g2, self.origin_box)
        dis = dis[dis != 0]  # 过滤掉距离为0的值
        ids = np.floor(dis / self.binsize).astype(np.int)
        ids = ids[ids < self.X.shape[0] - 1]

        # 更新RDF合并统计
        for i in ids:
            self.rdf_merge[i] += 1
            
        self.volume += self.origin_box**3  # 更新体积
        print(f"Calculating Frame = {frame}  Time Spent = {self.get_elapsed_time()}")

    def conclude(self, len_frame):
        """计算最终的RDF并输出结果"""
        shell_vol = self.binsize * 4 * np.pi * (self.X[1:] - 0.5 * self.binsize)**2
        box_vol = self.volume / len_frame
        density = self.N / box_vol
        rdf = self.rdf_merge / (density * shell_vol)
        self.rdf = rdf

    def get_elapsed_time(self):
        """获取从实例化到当前的时间"""
        return str(datetime.timedelta(seconds=time.time() - self.start_time))

# 主程序
if __name__ == "__main__":
    # 创建Universe实例
    u = mda.Universe('zzzz-tuihuo-final-eq.tpr', 'zzzz-tuihuo-final-eq.xtc')

    # 分别初始化BEAD组
    BEAD_A = BEAD_A.split('residue')
    BEAD_B = BEAD_B.split('residue')
    BEAD_C = BEAD_C.split('residue')
    BEAD_S1 = BEAD_S1.split('residue')
    BEAD_S2 = BEAD_S2.split('residue')

    # 合并BEAD_S
    BEAD_S = [BEAD_S1[i] for i in range(len(BEAD_S1))] + [BEAD_S2[i] for i in range(len(BEAD_S2))]

    # 设置残基名称
    resname = np.asarray(list('ABC' * 360))
    resname1 = np.asarray(list('SS' * 1080))

    # 获取各个类型的残基索引
    A_rank = np.argwhere(resname == 'A').ravel()
    B_rank = np.argwhere(resname == 'B').ravel()
    C_rank = np.argwhere(resname == 'C').ravel()
    S_rank = np.argwhere(resname1 == 'S').ravel()

    # 计算不同组分的RDF
    rdf_pairs = [
        (BEAD_A, BEAD_A, A_rank, A_rank, 'AA-RDF.dat'),
        (BEAD_A, BEAD_B, A_rank, B_rank, 'AB-RDF.dat'),
        (BEAD_A, BEAD_C, A_rank, C_rank, 'AC-RDF.dat'),
        (BEAD_B, BEAD_B, B_rank, B_rank, 'BB-RDF.dat'),
        (BEAD_B, BEAD_C, B_rank, C_rank, 'BC-RDF.dat'),
        (BEAD_C, BEAD_C, C_rank, C_rank, 'CC-RDF.dat'),
        (BEAD_S, BEAD_A, S_rank, A_rank, 'SA-RDF.dat'),
        (BEAD_S, BEAD_B, S_rank, B_rank, 'SB-RDF.dat'),
        (BEAD_S, BEAD_C, S_rank, C_rank, 'SC-RDF.dat')
    ]

    # 迭代计算每对组分的RDF
    for bead1, bead2, index1, index2, filename in rdf_pairs:
        rdf = new_RDF(u, bead1, bead2, index1, index2, 0.1)
        for frame in range(1, len(u.trajectory)):
            rdf.single_frame(frame)
        rdf.conclude(len(u.trajectory))
        np.savetxt(filename, np.c_[rdf.X[:-1], rdf.rdf], fmt='%.6f')

    # 结束信息输出
    from datetime import datetime
    print("============================== 任务完成 ====================================")
    print("======================== 完成于 %s =============================" % (datetime.now().strftime('%Y-%m-%d %H:%M:%S')))


