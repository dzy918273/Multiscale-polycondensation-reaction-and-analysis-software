import subprocess
import os

# 设置项目目录路径
PROJECT_DIR = '/path/to/project_directory'  # 替换为实际路径

# 定义模块执行函数
def run_DFT_cal_energy_barrier():
    """运行 1_DFT_cal_energy_barrier 模块"""
    print("Step 1: Running 1_DFT_cal.py (DFT 能量障碍计算)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "1_DFT_cal_energy_barrier", "1_DFT_cal.py")], check=True)

def run_TST_cal_k():
    """运行 2_TST_cal_k 模块"""
    print("Step 2: Running 2_TST_cal_k.py (计算反应速率常数)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "2_TST_cal_k", "2_TST_cal_k.py")], check=True)

def run_boltzmann_inversion():
    """运行 3_IBI-CGFF / 2_CG_BI_init_pot 模块"""
    print("Step 3: Running run_boltzmann_inversion.py (势能反演)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "3_IBI-CGFF", "2_CG_BI_init_pot", "run_boltzmann_inversion.py")], check=True)

def run_CG_distribution_scheduler():
    """运行 3_IBI-CGFF / 3_IBI_pot / 1_cal_CG_distribution / scheduler.py"""
    print("Step 4: Running scheduler.py (配位分布调度)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "3_IBI-CGFF", "3_IBI_pot", "1_cal_CG_distribution", "scheduler.py")], check=True)

def run_IBI_pot_scheduler():
    """运行 3_IBI-CGFF / 3_IBI_pot / scheduler.py"""
    print("Step 5: Running scheduler.py (进一步调度计算)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "3_IBI-CGFF", "3_IBI_pot", "scheduler.py")], check=True)

def run_CG_reaction():
    """运行 4_CG-reation 模块"""
    print("Step 6: Running CG-reaction.py (粗粒度反应模拟)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "4_CG-reation", "CG-reaction.py")], check=True)

def run_conversion_rate():
    """运行 5_conversion_rate 模块"""
    print("Step 7: Running conversion_rate.py (计算转化率)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "5_conversion_rate", "conversion_rate.py")], check=True)

def run_MWD():
    """运行 6_MWD 模块"""
    print("Step 8: Running PDI.py (计算分子量分布)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "6_MWD", "PDI.py")], check=True)

def run_stress_strain():
    """运行 7_stress-strain 模块"""
    print("Step 9: Running cal_stress-strain.py (应力应变分析)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "7_stress-strain", "cal_stress-strain.py")], check=True)

def main():
    """主控制函数，执行每个步骤"""
    print("开始自动化流程...")

    # 按照顺序执行每个步骤
    run_DFT_cal_energy_barrier()
    run_TST_cal_k()
    run_boltzmann_inversion()
    run_CG_distribution_scheduler()
    run_IBI_pot_scheduler()
    run_CG_reaction()
    run_conversion_rate()
    run_MWD()
    run_stress_strain()

    # 执行主控制程序
    print("Step 10: Running Main_control.py (主控制程序)...")
    subprocess.run(["python", os.path.join(PROJECT_DIR, "8_Main_control_program", "Main_control.py")], check=True)

    print("自动化流程已完成!")

if __name__ == "__main__":
    main()

